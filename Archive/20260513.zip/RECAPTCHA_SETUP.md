# Google reCAPTCHA Setup Instructions

This website uses Google reCAPTCHA v2 to protect the contact form from spam and abuse.

## Setup Steps

### 1. Register Your Site with Google reCAPTCHA
1. Go to [https://www.google.com/recaptcha/admin/create](https://www.google.com/recaptcha/admin/create)
2. Sign in with your Google account
3. Fill out the registration form:
   - **Label**: `XEnablers Contact Form` (or any name you prefer)
   - **reCAPTCHA type**: Select **reCAPTCHA v2** → **"I'm not a robot" Checkbox**
   - **Domains**: Add your domains:
     - `https://kind-sand-068ffa01e.7.azurestaticapps.net`
     - `xenablers.ai` (if using custom domain)
     - `localhost` (for local testing)
   - **Owners**: Your email address
   - Accept the reCAPTCHA Terms of Service
4. Click **Submit**

### 2. Get Your Keys
After registration, you'll receive two keys:
- **Site Key** (public key) - Used in the HTML - 
- **Secret Key** (private key) - Keep this secure, used for server-side verification

### 3. Update contact.html
Replace the placeholder in `contact.html`:

**Line ~56** (in the form):
```html
<div class="g-recaptcha" data-sitekey="YOUR_RECAPTCHA_SITE_KEY"></div>
```

Replace `YOUR_RECAPTCHA_SITE_KEY` with your actual **Site Key**.

Example:
```html
<div class="g-recaptcha" data-sitekey="6LcXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"></div>
```

### 4. Current Implementation
- **Client-side validation**: Form won't submit without completing reCAPTCHA
- **Visual feedback**: Error message if reCAPTCHA not completed
- **Auto-reset**: reCAPTCHA resets after successful form submission

### 5. Optional: Server-Side Verification
For enhanced security, you should verify the reCAPTCHA response on the server side. This requires:

1. Add an Azure Function or API endpoint
2. Send the reCAPTCHA response to Google's verification endpoint:
   ```
   POST https://www.google.com/recaptcha/api/siteverify
   secret=YOUR_SECRET_KEY&response=RECAPTCHA_RESPONSE
   ```
3. Only send email if verification passes

**Note**: The current implementation uses client-side validation only, which provides basic spam protection.

## Testing
1. Update `contact.html` with your Site Key
2. Commit and push changes
3. Wait for deployment
4. Visit https://kind-sand-068ffa01e.7.azurestaticapps.net
5. Try submitting without completing reCAPTCHA (should show error)
6. Complete reCAPTCHA and submit (should work)

## Troubleshooting
- **reCAPTCHA doesn't appear**: Check browser console for errors, verify Site Key is correct
- **Domain not allowed**: Add your domain to the reCAPTCHA admin console
- **Works locally but not in production**: Ensure production domain is added to allowed domains
- **"ERROR for site owner"**: Check that Site Key matches the registered site

## Security Best Practices
- Never commit your Secret Key to the repository
- Use environment variables for keys in production
- Implement server-side verification for production sites
- Monitor reCAPTCHA analytics in the admin console
